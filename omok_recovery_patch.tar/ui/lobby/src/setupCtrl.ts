import { INITIAL_FEN } from 'chessops/fen';

import { type Prop, propWithEffect, toggle } from 'lib';
import { debounce } from 'lib/async';
import type { ColorChoice, ColorProp } from 'lib/setup/color';
import {
  allTimeModeKeys,
  timeControlFromStoredValues,
  timeModes,
  type TimeControl,
} from 'lib/setup/timeControl';
import { storedJsonProp } from 'lib/storage';
import { alert } from 'lib/view';
import * as xhr from 'lib/xhr';

import type LobbyController from './ctrl';
import * as hookRepo from './hookRepo';
import type { ForceSetupOptions, GameMode, GameType, OmokRuleSet, PoolMember, SetupStore } from './interfaces';
import { keyToId, variants } from './options';

const getPerf = (variant: VariantKey, tc: TimeControl): Perf =>
  variant !== 'standard' && variant !== 'fromPosition' ? variant : tc.speed();

export default class SetupController {
  root: LobbyController;
  store: Record<GameType, Prop<SetupStore>>;
  gameType: GameType | null = null;
  lastValidFen = '';
  fenError = false;
  friendUser = '';
  loading = false;
  color: ColorProp;
  forced?: ForceSetupOptions;

  // Store props
  variant: Prop<VariantKey>;
  omokRuleSet: Prop<OmokRuleSet>;
  fen: Prop<string>;
  gameMode: Prop<GameMode>;
  ratingMin: Prop<number>;
  ratingMax: Prop<number>;
  aiLevel: Prop<number>;
  omokAiThreads: Prop<number>;
  omokAiMoveTimeMs: Prop<number>;
  omokAiDepth: Prop<number>;
  omokAiNodes: Prop<number>;
  omokAiAnalysisEnabled: Prop<boolean>;

  variantMenuOpen = toggle(false);

  timeControl: TimeControl;

  constructor(ctrl: LobbyController) {
    this.root = ctrl;
    this.color = propWithEffect('random', this.onPropChange);
    // Initialize stores with default props as necessary
    this.store = {
      hook: this.makeSetupStore('hook'),
      friend: this.makeSetupStore('friend'),
      ai: this.makeSetupStore('ai'),
    };
  }

  // Namespace the store by username for user specific modal settings
  private readonly storeKey = (gameType: GameType) =>
    `lobby.setup.${this.root.me?.username || 'anon'}.${gameType}`;

  makeSetupStore = (gameType: GameType) =>
    storedJsonProp<SetupStore>(this.storeKey(gameType), () => ({
      variant: 'standard',
      omokRuleSet: gameType === 'ai' ? 'renju' : 'taraguchi10',
      fen: '',
      timeMode: gameType === 'hook' ? 'realTime' : 'unlimited',
      time: 5,
      increment: 3,
      days: 2,
      gameMode: gameType === 'ai' || !this.root.me ? 'casual' : 'rated',
      ratingMin: -500,
      ratingMax: 500,
      aiLevel: 1,
      omokAiThreads: 1,
      omokAiMoveTimeMs: 800,
      omokAiDepth: 0,
      omokAiNodes: 0,
      omokAiAnalysisEnabled: true,
    }));

  private readonly loadPropsFromStore = (forceOptions?: ForceSetupOptions) => {
    const storeProps = this.store[this.gameType!]();
    // Load props from the store, but override any store values with values found in forceOptions
    this.variant = propWithEffect(forceOptions?.variant || storeProps.variant, this.onDropdownChange);
    const preferredOmokRuleSet =
      this.gameType === 'ai'
        ? storeProps.omokRuleSet || 'renju'
        : storeProps.omokRuleSet || 'taraguchi10';
    this.omokRuleSet = this.propWithApply(preferredOmokRuleSet);
    this.fen = this.propWithApply(forceOptions?.fen || storeProps.fen);
    const canChangeTimeMode = !!this.root.me || this.gameType !== 'hook';
    this.timeControl = timeControlFromStoredValues(
      propWithEffect(forceOptions?.timeMode || storeProps.timeMode, this.onDropdownChange),
      canChangeTimeMode ? allTimeModeKeys : ['realTime'],
      forceOptions?.time ?? storeProps.time,
      forceOptions?.increment ?? storeProps.increment,
      forceOptions?.days ?? storeProps.days,
      this.onPropChange,
      this.root.pools,
    );
    this.gameMode = this.propWithApply(forceOptions?.mode ?? storeProps.gameMode);
    this.ratingMin = this.propWithApply(storeProps.ratingMin);
    this.ratingMax = this.propWithApply(storeProps.ratingMax);
    this.aiLevel = this.propWithApply(storeProps.aiLevel);
    this.omokAiThreads = this.propWithApply(storeProps.omokAiThreads || 1);
    this.omokAiMoveTimeMs = this.propWithApply(storeProps.omokAiMoveTimeMs || 800);
    this.omokAiDepth = this.propWithApply(storeProps.omokAiDepth || 0);
    this.omokAiNodes = this.propWithApply(storeProps.omokAiNodes || 0);
    this.omokAiAnalysisEnabled = this.propWithApply(storeProps.omokAiAnalysisEnabled ?? true);
    this.color(forceOptions?.color || 'random');

    this.enforcePropRules();
    // Upon loading the props from the store, overriding with forced options, and enforcing rules,
    // immediately save them to the store. This way, the user can know that whatever they saw last
    // in the modal will be there when they open it at a later time.
    this.savePropsToStore();
  };

  private readonly enforcePropRules = () => {
    // reassign with this.propWithApply in this function to avoid calling this.onPropChange

    // replace underscores with spaces in FEN
    if (this.variant() === 'fromPosition') this.fen = this.propWithApply(this.fen().replace(/_/g, ' '));

    if (this.gameMode() === 'rated' && this.ratedModeDisabled()) {
      this.gameMode = this.propWithApply('casual');
    }

    this.ratingMin = this.propWithApply(Math.min(0, this.ratingMin()));
    this.ratingMax = this.propWithApply(Math.max(0, this.ratingMax()));
    if (this.ratingMin() === 0 && this.ratingMax() === 0) {
      this.ratingMax = this.propWithApply(50);
    }
  };

  private readonly savePropsToStore = (override: Partial<SetupStore> = {}) =>
    this.gameType &&
    this.store[this.gameType]({
      variant: this.variant(),
      omokRuleSet: this.omokRuleSet(),
      fen: this.fen(),
      timeMode: this.timeControl.mode(),
      time: this.timeControl.time(),
      increment: this.timeControl.increment(),
      days: this.timeControl.days(),
      gameMode: this.gameMode(),
      ratingMin: this.ratingMin(),
      ratingMax: this.ratingMax(),
      aiLevel: this.aiLevel(),
      omokAiThreads: this.omokAiThreads(),
      omokAiMoveTimeMs: this.omokAiMoveTimeMs(),
      omokAiDepth: this.omokAiDepth(),
      omokAiNodes: this.omokAiNodes(),
      omokAiAnalysisEnabled: this.omokAiAnalysisEnabled(),
      ...override,
    });

  private readonly savePropsToStoreExceptRating = () =>
    this.gameType &&
    this.savePropsToStore({
      ratingMin: this.store[this.gameType]().ratingMin,
      ratingMax: this.store[this.gameType]().ratingMax,
    });

  myRating = () => this.root.data.ratingMap && Math.abs(this.root.data.ratingMap[this.selectedPerf()]);
  isProvisional = () => (this.root.data.ratingMap ? this.root.data.ratingMap[this.selectedPerf()] < 0 : true);

  private readonly onPropChange = () => {
    if (this.isProvisional()) this.savePropsToStoreExceptRating();
    else this.savePropsToStore();
    this.root.redraw();
  };

  private readonly onDropdownChange = () => {
    // Handle rating update here
    this.enforcePropRules();
    if (this.isProvisional()) {
      this.ratingMin(-500);
      this.ratingMax(500);
      this.savePropsToStoreExceptRating();
    } else {
      if (this.gameType) {
        this.ratingMin(this.store[this.gameType]().ratingMin);
        this.ratingMax(this.store[this.gameType]().ratingMax);
      }
      this.savePropsToStore();
    }
    this.root.redraw();
  };

  private readonly propWithApply = <A>(value: A) => propWithEffect(value, this.onPropChange);

  openModal = (
    gameType: Exclude<GameType, 'local'>,
    forceOptions?: ForceSetupOptions,
    friendUser?: string,
  ) => {
    this.root.leavePool();
    this.gameType = gameType;
    this.loading = false;
    this.fenError = false;
    this.lastValidFen = '';
    this.friendUser = friendUser || '';
    this.variantMenuOpen(false);
    this.forced = forceOptions;
    this.loadPropsFromStore(forceOptions);
  };

  closeModal?: () => void; // managed by view/setup/modal.ts

  toggleVariantMenu = () => {
    this.variantMenuOpen.toggle();
    this.root.redraw();
  };

  validateFen = debounce(() => {
    const fen = this.fen();
    if (!fen) return;
    xhr
      .text(
        xhr.url('/setup/validate-fen', {
          fen,
          strict: this.gameType === 'ai' ? 1 : undefined,
        }),
      )
      .then(
        () => {
          this.fenError = false;
          this.lastValidFen = fen;
          this.root.redraw();
        },
        () => {
          this.fenError = true;
          this.root.redraw();
        },
      );
  }, 300);

  ratedModeDisabled = () =>
    // anonymous games cannot be rated
    !this.root.me ||
    this.timeControl.mode() === 'unlimited' ||
    (this.variant() === 'fromPosition' && this.fen() !== INITIAL_FEN) ||
    // variants with very low time cannot be rated
    (this.variant() !== 'standard' && this.timeControl.notForRatedVariant());

  selectedPerf = (): Perf => getPerf(this.variant(), this.timeControl);

  ratingRange = (): string => {
    const rating = this.myRating();
    return rating ? `${Math.max(100, rating + this.ratingMin())}-${rating + this.ratingMax()}` : '';
  };

  hookToPoolMember = (color: ColorChoice): PoolMember | null => {
    const valid =
      color === 'random' &&
      this.gameType === 'hook' &&
      this.variant() === 'standard' &&
      this.gameMode() === 'rated' &&
      this.timeControl.isRealTime();
    const id = this.timeControl.clockStr();
    return valid && this.root.pools.some(p => p.id === id)
      ? {
          id,
          range: this.ratingRange(),
        }
      : null;
  };

  propsToFormData = (color: ColorChoice) =>
    xhr.form({
      variant: keyToId(this.variant(), variants).toString(),
      omokRuleSet:
        this.gameType === 'hook' || this.gameType === 'ai' || this.gameType === 'friend'
          ? this.omokRuleSet()
          : undefined,
      fen: this.variant() === 'fromPosition' ? this.fen() : undefined,
      timeMode: keyToId(this.timeControl.mode(), timeModes).toString(),
      time: this.timeControl.time().toString(),
      time_range: this.timeControl.timeV().toString(),
      increment: this.timeControl.increment().toString(),
      increment_range: this.timeControl.incrementV().toString(),
      days: this.timeControl.days().toString(),
      days_range: this.timeControl.daysV().toString(),
      mode: this.gameMode() === 'casual' ? '0' : '1',
      ratingRange: this.ratingRange(),
      ratingRange_range_min: this.ratingMin().toString(),
      ratingRange_range_max: this.ratingMax().toString(),
      level: this.aiLevel().toString(),
      omokThreads: this.gameType === 'ai' ? this.omokAiThreads().toString() : undefined,
      omokMoveTimeMs: this.gameType === 'ai' ? this.omokAiMoveTimeMs().toString() : undefined,
      omokDepth: this.gameType === 'ai' && this.omokAiDepth() > 0 ? this.omokAiDepth().toString() : undefined,
      omokNodes: this.gameType === 'ai' && this.omokAiNodes() > 0 ? this.omokAiNodes().toString() : undefined,
      omokAnalysisEnabled: this.gameType === 'ai' ? (this.omokAiAnalysisEnabled() ? 'true' : 'false') : undefined,
      color,
    });

  validFen = () => this.variant() !== 'fromPosition' || (!this.fenError && !!this.fen());

  valid = () =>
    this.validFen() && this.timeControl.valid(this.minimumTimeIfReal()) && this.validConstraints();

  private readonly invalid = <A>(forced: A | undefined, current: A) =>
    forced !== undefined && forced !== current;

  private readonly validConstraints = () => {
    if (this.forced) {
      if (this.invalid(this.forced.variant, this.variant())) return false;
      if (this.invalid(this.forced.mode, this.gameMode())) return false;
      if (this.invalid(this.forced.timeMode, this.timeControl.mode())) return false;
      if (this.invalid(this.forced.color, this.color())) return false;
      if (
        this.timeControl.mode() === 'correspondence' &&
        this.invalid(this.forced.days, this.timeControl.days())
      )
        return false;
      if (this.timeControl.mode() === 'realTime') {
        if (this.invalid(this.forced.time, this.timeControl.time())) return false;
        if (this.invalid(this.forced.increment, this.timeControl.increment())) return false;
      }
      if (this.invalid(this.forced.fen?.replace(/_/g, ' '), this.fen())) return false;
    }
    return true;
  };

  minimumTimeIfReal = () => (this.gameType === 'ai' && this.variant() === 'fromPosition' ? 1 : 0);

  submit = async () => {
    const color = this.color();
    const poolMember = this.hookToPoolMember(color);
    if (poolMember) {
      this.root.enterPool(poolMember);
      this.closeModal?.();
      return;
    }

    if (this.gameType === 'hook') this.root.setTab(this.timeControl.isRealTime() ? 'real_time' : 'seeks');
    this.loading = true;
    this.root.redraw();

    let urlPath = `/setup/${this.gameType}`;
    if (this.gameType === 'hook') urlPath += `/${site.sri}`;
    const urlParams = { user: this.friendUser || undefined };
    let response;
    try {
      response = await xhr.textRaw(xhr.url(urlPath, urlParams), {
        method: 'post',
        body: this.propsToFormData(color),
      });
    } catch (_) {
      this.loading = false;
      this.root.redraw();
      await alert('Sorry, we encountered an error while creating your game. Please try again.');
      return;
    }

    const { ok, redirected, url } = response;

    if (!ok) {
      const errs: Record<string, string> = await response.json();
      await alert(
        errs
          ? Object.keys(errs)
              .map(k => `${k}: ${errs[k]}`)
              .join('\n')
          : 'Invalid setup',
      );
      if (response.status === 403) {
        // 403 FORBIDDEN closes this modal because challenges to the recipient
        // will not be accepted.  see friend() in controllers/Setup.scala
        this.closeModal?.();
      }
    } else if (redirected) {
      location.href = url;
    } else {
      if (this.gameType === 'hook') {
        try {
          const payload = await response.json();
          const hook = payload?.hook?.id
            ? {
                sri: site.sri,
                clock: payload.hook.clock ?? `${this.timeControl.time()}+${this.timeControl.increment()}`,
                t: payload.hook.t ?? Math.round(this.timeControl.time() * 60 + this.timeControl.increment() * 40),
                s: payload.hook.s ?? 0,
                i: payload.hook.i ?? (this.timeControl.increment() > 0 ? 1 : 0),
                variant: payload.hook.variant ?? this.variant(),
                perf: payload.hook.perf ?? this.selectedPerf(),
                u: payload.hook.u ?? this.root.me?.username,
                rating: payload.hook.rating ?? this.myRating(),
                prov: payload.hook.prov ?? (this.isProvisional() ? true : undefined),
                ra: payload.hook.ra ?? (this.gameMode() === 'rated' ? 1 : undefined),
                ...payload.hook,
              }
            : null;
          if (hook?.id) {
            hookRepo.add(this.root, hook as any);
            this.root.flushHooks(true);
          }
        } catch {}
      }
      this.loading = false;
      this.closeModal?.();
      this.root.redraw();
    }
  };
}
